import React, { useState, useRef, useCallback, useEffect } from 'react';
import { 
  Square, 
  Circle, 
  Pentagon, 
  Minus, 
  Type, 
  MousePointer, 
  ZoomIn, 
  Move, 
  Grid, 
  Eye, 
  EyeOff, 
  Lock, 
  Unlock, 
  Copy, 
  Trash2, 
  RotateCcw, 
  RotateCw, 
  Keyboard,
  Sun,
  Moon,
  FolderOpen,
  Plus,
  Settings,
  Home,
  Layers,
  Image as ImageIcon,
  FileText,
  Database,
  Users,
  BarChart3,
  Calendar,
  Bell,
  Search,
  Filter,
  Download,
  Upload,
  Share2,
  Archive
} from 'lucide-react';
import Canvas, { CanvasRef } from './components/Canvas';
import ToolButton from './components/ToolButton';
import ClassManager from './components/ClassManager';
import FileManager from './components/FileManager';
import AnnotationList from './components/AnnotationList';
import StatusBar from './components/StatusBar';
import KeyboardShortcuts from './components/KeyboardShortcuts';

interface Point {
  x: number;
  y: number;
}

interface Annotation {
  id: string;
  type: 'rectangle' | 'circle' | 'polygon' | 'polyline' | 'text';
  label: string;
  points: Point[];
  visible: boolean;
  locked: boolean;
  text?: string;
  fontSize?: number;
}

interface Project {
  id: string;
  name: string;
  description: string;
  imageCount: number;
  annotationCount: number;
  lastModified: Date;
  status: 'active' | 'completed' | 'archived';
  thumbnail?: string;
}

type Tool = 'select' | 'rectangle' | 'circle' | 'polygon' | 'polyline' | 'text' | 'zoom' | 'pan';
type DashboardView = 'projects' | 'annotation-tool' | 'analytics' | 'settings';

export default function App() {
  const canvasRef = useRef<CanvasRef>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Dashboard state
  const [currentView, setCurrentView] = useState<DashboardView>('projects');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [projects, setProjects] = useState<Project[]>([
    {
      id: '1',
      name: 'Medical Image Analysis',
      description: 'Annotating X-ray images for AI training',
      imageCount: 245,
      annotationCount: 1230,
      lastModified: new Date('2024-01-15'),
      status: 'active'
    },
    {
      id: '2',
      name: 'Autonomous Vehicle Dataset',
      description: 'Street scene object detection annotations',
      imageCount: 1500,
      annotationCount: 8750,
      lastModified: new Date('2024-01-14'),
      status: 'active'
    },
    {
      id: '3',
      name: 'Satellite Imagery Classification',
      description: 'Land use classification for urban planning',
      imageCount: 89,
      annotationCount: 445,
      lastModified: new Date('2024-01-10'),
      status: 'completed'
    },
    {
      id: '4',
      name: 'Wildlife Conservation Study',
      description: 'Animal detection in camera trap images',
      imageCount: 320,
      annotationCount: 960,
      lastModified: new Date('2024-01-08'),
      status: 'archived'
    }
  ]);
  
  // Annotation tool state
  const [tool, setTool] = useState<Tool>('select');
  const [annotations, setAnnotations] = useState<Annotation[]>([]);
  const [selectedAnnotation, setSelectedAnnotation] = useState<string | null>(null);
  const [classList, setClassList] = useState<string[]>(['default']);
  const [selectedClass, setSelectedClass] = useState<string>('default');
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentPoints, setCurrentPoints] = useState<Point[]>([]);
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState<Point>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [lastPanPoint, setLastPanPoint] = useState<Point>({ x: 0, y: 0 });
  const [showGrid, setShowGrid] = useState(false);
  const [showAll, setShowAll] = useState(true);
  const [mousePos, setMousePos] = useState<Point>({ x: 0, y: 0 });
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 600 });

  // Convert screen coordinates to canvas coordinates with proper scaling
  const screenToCanvas = useCallback((screenX: number, screenY: number): Point => {
    const canvas = canvasRef.current?.getContext()?.canvas;
    if (!canvas) return { x: screenX, y: screenY };
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    
    const canvasX = (screenX - rect.left) * scaleX;
    const canvasY = (screenY - rect.top) * scaleY;
    
    // Apply inverse transform to get actual image coordinates
    const imageX = (canvasX - offset.x) / scale;
    const imageY = (canvasY - offset.y) / scale;
    
    return { x: imageX, y: imageY };
  }, [scale, offset]);

  // Convert canvas coordinates to screen coordinates
  const canvasToScreen = useCallback((canvasX: number, canvasY: number): Point => {
    const screenX = canvasX * scale + offset.x;
    const screenY = canvasY * scale + offset.y;
    return { x: screenX, y: screenY };
  }, [scale, offset]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    const point = screenToCanvas(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
    setMousePos(point);

    if (tool === 'pan') {
      setIsPanning(true);
      setLastPanPoint({ x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY });
      return;
    }

    if (tool === 'zoom') {
      const zoomFactor = e.shiftKey ? 0.8 : 1.25;
      const newScale = Math.max(0.1, Math.min(5, scale * zoomFactor));
      
      // Zoom towards the mouse position
      const mouseCanvas = { x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY };
      const newOffset = {
        x: mouseCanvas.x - (mouseCanvas.x - offset.x) * (newScale / scale),
        y: mouseCanvas.y - (mouseCanvas.y - offset.y) * (newScale / scale)
      };
      
      setScale(newScale);
      setOffset(newOffset);
      return;
    }

    if (tool === 'select') {
      // Find annotation at click point
      const clickedAnnotation = annotations.find(ann => {
        if (!ann.visible || ann.locked) return false;
        
        if (ann.type === 'rectangle' && ann.points.length >= 2) {
          const [p1, p2] = ann.points;
          return point.x >= Math.min(p1.x, p2.x) && point.x <= Math.max(p1.x, p2.x) &&
                 point.y >= Math.min(p1.y, p2.y) && point.y <= Math.max(p1.y, p2.y);
        }
        
        if (ann.type === 'circle' && ann.points.length >= 2) {
          const [center, edge] = ann.points;
          const radius = Math.sqrt(Math.pow(edge.x - center.x, 2) + Math.pow(edge.y - center.y, 2));
          const distance = Math.sqrt(Math.pow(point.x - center.x, 2) + Math.pow(point.y - center.y, 2));
          return distance <= radius;
        }
        
        return false;
      });
      
      setSelectedAnnotation(clickedAnnotation?.id || null);
      return;
    }

    if (['rectangle', 'circle', 'text'].includes(tool)) {
      setIsDrawing(true);
      setCurrentPoints([point]);
    }

    if (['polygon', 'polyline'].includes(tool)) {
      setCurrentPoints(prev => [...prev, point]);
    }
  }, [tool, scale, offset, annotations, screenToCanvas]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const point = screenToCanvas(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
    setMousePos(point);

    if (isPanning && tool === 'pan') {
      const deltaX = e.nativeEvent.offsetX - lastPanPoint.x;
      const deltaY = e.nativeEvent.offsetY - lastPanPoint.y;
      
      setOffset(prev => ({
        x: prev.x + deltaX,
        y: prev.y + deltaY
      }));
      
      setLastPanPoint({ x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY });
      return;
    }

    if (isDrawing && ['rectangle', 'circle'].includes(tool)) {
      setCurrentPoints(prev => [prev[0], point]);
    }
  }, [tool, isDrawing, isPanning, lastPanPoint, screenToCanvas]);

  const handleMouseUp = useCallback(() => {
    if (isPanning) {
      setIsPanning(false);
      return;
    }

    if (isDrawing && currentPoints.length >= 2) {
      const newAnnotation: Annotation = {
        id: Date.now().toString(),
        type: tool as 'rectangle' | 'circle',
        label: selectedClass,
        points: currentPoints,
        visible: true,
        locked: false
      };

      if (tool === 'text') {
        const text = prompt('Enter text:');
        if (text) {
          newAnnotation.text = text;
          newAnnotation.fontSize = 16;
        } else {
          setIsDrawing(false);
          setCurrentPoints([]);
          return;
        }
      }

      setAnnotations(prev => [...prev, newAnnotation]);
      setIsDrawing(false);
      setCurrentPoints([]);
    }
  }, [isDrawing, currentPoints, tool, selectedClass]);

  const handleDoubleClick = useCallback(() => {
    if (['polygon', 'polyline'].includes(tool) && currentPoints.length >= 2) {
      const newAnnotation: Annotation = {
        id: Date.now().toString(),
        type: tool as 'polygon' | 'polyline',
        label: selectedClass,
        points: currentPoints,
        visible: true,
        locked: false
      };

      setAnnotations(prev => [...prev, newAnnotation]);
      setCurrentPoints([]);
    }
  }, [tool, currentPoints, selectedClass]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    if (e.ctrlKey) {
      e.preventDefault();
      const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
      const newScale = Math.max(0.1, Math.min(5, scale * zoomFactor));
      
      // Zoom towards the mouse position
      const mouseCanvas = { x: e.nativeEvent.offsetX, y: e.nativeEvent.offsetY };
      const newOffset = {
        x: mouseCanvas.x - (mouseCanvas.x - offset.x) * (newScale / scale),
        y: mouseCanvas.y - (mouseCanvas.y - offset.y) * (newScale / scale)
      };
      
      setScale(newScale);
      setOffset(newOffset);
    }
  }, [scale, offset]);

  const drawFunction = useCallback((ctx: CanvasRenderingContext2D) => {
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    
    // Apply transform
    ctx.save();
    ctx.translate(offset.x, offset.y);
    ctx.scale(scale, scale);

    // Draw image if loaded
    if (image && imageLoaded) {
      ctx.drawImage(image, 0, 0);
    }

    // Draw grid if enabled
    if (showGrid) {
      ctx.strokeStyle = darkMode ? 'rgba(255, 255, 255, 0.2)' : 'rgba(0, 0, 0, 0.1)';
      ctx.lineWidth = 1 / scale;
      const gridSize = 50;
      
      for (let x = 0; x < canvasSize.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvasSize.height);
        ctx.stroke();
      }
      
      for (let y = 0; y < canvasSize.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvasSize.width, y);
        ctx.stroke();
      }
    }

    // Draw annotations
    annotations.forEach(annotation => {
      if (!annotation.visible && showAll) return;
      
      ctx.strokeStyle = annotation.id === selectedAnnotation ? '#3b82f6' : '#ef4444';
      ctx.fillStyle = annotation.id === selectedAnnotation ? 'rgba(59, 130, 246, 0.2)' : 'rgba(239, 68, 68, 0.2)';
      ctx.lineWidth = 2 / scale;

      if (annotation.type === 'rectangle' && annotation.points.length >= 2) {
        const [p1, p2] = annotation.points;
        const width = p2.x - p1.x;
        const height = p2.y - p1.y;
        ctx.fillRect(p1.x, p1.y, width, height);
        ctx.strokeRect(p1.x, p1.y, width, height);
      }

      if (annotation.type === 'circle' && annotation.points.length >= 2) {
        const [center, edge] = annotation.points;
        const radius = Math.sqrt(Math.pow(edge.x - center.x, 2) + Math.pow(edge.y - center.y, 2));
        ctx.beginPath();
        ctx.arc(center.x, center.y, radius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
      }

      if (['polygon', 'polyline'].includes(annotation.type) && annotation.points.length >= 2) {
        ctx.beginPath();
        ctx.moveTo(annotation.points[0].x, annotation.points[0].y);
        annotation.points.slice(1).forEach(point => {
          ctx.lineTo(point.x, point.y);
        });
        if (annotation.type === 'polygon') {
          ctx.closePath();
          ctx.fill();
        }
        ctx.stroke();
      }

      if (annotation.type === 'text' && annotation.points.length >= 1 && annotation.text) {
        ctx.font = `${(annotation.fontSize || 16) / scale}px Arial`;
        ctx.fillStyle = annotation.id === selectedAnnotation ? '#3b82f6' : '#ef4444';
        ctx.fillText(annotation.text, annotation.points[0].x, annotation.points[0].y);
      }
    });

    // Draw current drawing
    if (isDrawing && currentPoints.length > 0) {
      ctx.strokeStyle = '#10b981';
      ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
      ctx.lineWidth = 2 / scale;

      if (tool === 'rectangle' && currentPoints.length === 2) {
        const [p1, p2] = currentPoints;
        const width = p2.x - p1.x;
        const height = p2.y - p1.y;
        ctx.fillRect(p1.x, p1.y, width, height);
        ctx.strokeRect(p1.x, p1.y, width, height);
      }

      if (tool === 'circle' && currentPoints.length === 2) {
        const [center, edge] = currentPoints;
        const radius = Math.sqrt(Math.pow(edge.x - center.x, 2) + Math.pow(edge.y - center.y, 2));
        ctx.beginPath();
        ctx.arc(center.x, center.y, radius, 0, 2 * Math.PI);
        ctx.fill();
        ctx.stroke();
      }
    }

    // Draw polygon/polyline in progress
    if (['polygon', 'polyline'].includes(tool) && currentPoints.length > 0) {
      ctx.strokeStyle = '#10b981';
      ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
      ctx.lineWidth = 2 / scale;

      ctx.beginPath();
      ctx.moveTo(currentPoints[0].x, currentPoints[0].y);
      currentPoints.slice(1).forEach(point => {
        ctx.lineTo(point.x, point.y);
      });
      
      // Draw line to current mouse position
      ctx.lineTo(mousePos.x, mousePos.y);
      
      if (tool === 'polygon' && currentPoints.length >= 3) {
        ctx.closePath();
        ctx.fill();
      }
      ctx.stroke();

      // Draw points
      currentPoints.forEach(point => {
        ctx.beginPath();
        ctx.arc(point.x, point.y, 4 / scale, 0, 2 * Math.PI);
        ctx.fillStyle = '#10b981';
        ctx.fill();
      });
    }

    ctx.restore();
  }, [image, imageLoaded, annotations, selectedAnnotation, isDrawing, currentPoints, tool, mousePos, showGrid, showAll, scale, offset, darkMode, canvasSize]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;

      switch (e.key.toLowerCase()) {
        case 'r': setTool('rectangle'); break;
        case 'c': setTool('circle'); break;
        case 'p': setTool('polygon'); break;
        case 'l': setTool('polyline'); break;
        case 't': setTool('text'); break;
        case 's': setTool('select'); break;
        case 'z': setTool('zoom'); break;
        case 'm': setTool('pan'); break;
        case 'g': setShowGrid(prev => !prev); break;
        case 'h': setShowAll(prev => !prev); break;
        case 'f1': e.preventDefault(); setShowShortcuts(prev => !prev); break;
        case 'escape':
          setCurrentPoints([]);
          setIsDrawing(false);
          setSelectedAnnotation(null);
          break;
        case 'delete':
        case 'backspace':
          if (selectedAnnotation) {
            setAnnotations(prev => prev.filter(ann => ann.id !== selectedAnnotation));
            setSelectedAnnotation(null);
          }
          break;
      }

      // Zoom shortcuts
      if (e.ctrlKey) {
        switch (e.key) {
          case '=':
          case '+':
            e.preventDefault();
            setScale(prev => Math.min(5, prev * 1.25));
            break;
          case '-':
            e.preventDefault();
            setScale(prev => Math.max(0.1, prev * 0.8));
            break;
          case '0':
            e.preventDefault();
            setScale(1);
            setOffset({ x: 0, y: 0 });
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedAnnotation]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const img = new Image();
      img.onload = () => {
        setImage(img);
        setImageLoaded(true);
        setCanvasSize({ width: img.width, height: img.height });
        setScale(1);
        setOffset({ x: 0, y: 0 });
      };
      img.src = URL.createObjectURL(file);
    }
  };

  const handleExport = () => {
    const data = {
      annotations,
      classList,
      imageSize: canvasSize,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'annotations.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const data = JSON.parse(event.target?.result as string);
          if (data.annotations) {
            setAnnotations(data.annotations);
          }
          if (data.classList) {
            setClassList(data.classList);
          }
        } catch (error) {
          alert('Invalid JSON file');
        }
      };
      reader.readAsText(file);
    }
  };

  const toggleAnnotationVisibility = (id: string) => {
    setAnnotations(prev => prev.map(ann => 
      ann.id === id ? { ...ann, visible: !ann.visible } : ann
    ));
  };

  const toggleAnnotationLock = (id: string) => {
    setAnnotations(prev => prev.map(ann => 
      ann.id === id ? { ...ann, locked: !ann.locked } : ann
    ));
  };

  const duplicateAnnotation = (id: string) => {
    const annotation = annotations.find(ann => ann.id === id);
    if (annotation) {
      const newAnnotation = {
        ...annotation,
        id: Date.now().toString(),
        points: annotation.points.map(p => ({ x: p.x + 10, y: p.y + 10 }))
      };
      setAnnotations(prev => [...prev, newAnnotation]);
    }
  };

  const deleteAnnotation = (id: string) => {
    setAnnotations(prev => prev.filter(ann => ann.id !== id));
    if (selectedAnnotation === id) {
      setSelectedAnnotation(null);
    }
  };

  const createNewProject = () => {
    const name = prompt('Enter project name:');
    if (name) {
      const newProject: Project = {
        id: Date.now().toString(),
        name,
        description: 'New annotation project',
        imageCount: 0,
        annotationCount: 0,
        lastModified: new Date(),
        status: 'active'
      };
      setProjects(prev => [newProject, ...prev]);
    }
  };

  const openProject = (project: Project) => {
    setSelectedProject(project);
    setCurrentView('annotation-tool');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const renderProjectsView = () => (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
            Projects Dashboard
          </h1>
          <p className={`mt-2 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Manage your annotation projects and datasets
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={createNewProject}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus size={20} />
            New Project
          </button>
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-lg transition-colors ${
              darkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
            }`}
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} rounded-xl p-6 border`}>
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <FolderOpen className="text-blue-600" size={24} />
            </div>
            <div className="ml-4">
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>Total Projects</p>
              <p className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>{projects.length}</p>
            </div>
          </div>
        </div>
        
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} rounded-xl p-6 border`}>
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <ImageIcon className="text-green-600" size={24} />
            </div>
            <div className="ml-4">
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>Total Images</p>
              <p className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {projects.reduce((sum, p) => sum + p.imageCount, 0)}
              </p>
            </div>
          </div>
        </div>
        
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} rounded-xl p-6 border`}>
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Layers className="text-purple-600" size={24} />
            </div>
            <div className="ml-4">
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>Total Annotations</p>
              <p className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {projects.reduce((sum, p) => sum + p.annotationCount, 0)}
              </p>
            </div>
          </div>
        </div>
        
        <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} rounded-xl p-6 border`}>
          <div className="flex items-center">
            <div className="p-2 bg-orange-100 rounded-lg">
              <BarChart3 className="text-orange-600" size={24} />
            </div>
            <div className="ml-4">
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>Active Projects</p>
              <p className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                {projects.filter(p => p.status === 'active').length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Quick Tool Card */}
        <div
          className={`${darkMode ? 'bg-gradient-to-br from-green-800 to-green-900 border-green-700 hover:from-green-700 hover:to-green-800' : 'bg-gradient-to-br from-green-50 to-green-100 border-green-200 hover:from-green-100 hover:to-green-200'} rounded-xl p-6 border transition-all cursor-pointer hover:shadow-lg hover:scale-105`}
          onClick={() => {
            setCurrentView('annotation-tool');
            setSelectedProject(null);
          }}
        >
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`p-3 rounded-lg ${darkMode ? 'bg-green-600' : 'bg-green-500'}`}>
                <Square className="text-white" size={24} />
              </div>
              <div>
                <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'} mb-1`}>
                  Quick Annotation Tool
                </h3>
                <p className={`text-sm ${darkMode ? 'text-green-200' : 'text-green-700'}`}>
                  Start annotating immediately
                </p>
              </div>
            </div>
            <span className={`px-3 py-1 text-xs font-medium rounded-full ${darkMode ? 'bg-green-600 text-green-100' : 'bg-green-500 text-white'}`}>
              Ready
            </span>
          </div>
          
          <div className={`text-sm ${darkMode ? 'text-green-200' : 'text-green-700'} mb-4`}>
            Jump straight into annotation mode without creating a project. Perfect for quick tasks, testing, or one-off annotations.
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex gap-4">
              <div>
                <p className={`text-xs ${darkMode ? 'text-green-300' : 'text-green-600'}`}>Features</p>
                <p className={`text-sm font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  All Tools
                </p>
              </div>
              <div>
                <p className={`text-xs ${darkMode ? 'text-green-300' : 'text-green-600'}`}>Export</p>
                <p className={`text-sm font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  JSON/CSV
                </p>
              </div>
            </div>
            <div className={`p-2 rounded-full ${darkMode ? 'bg-green-600' : 'bg-green-500'}`}>
              <Square className="text-white" size={16} />
            </div>
          </div>
        </div>
        
        {projects.map((project) => (
          <div
            key={project.id}
            className={`${darkMode ? 'bg-gray-800 border-gray-700 hover:bg-gray-750' : 'bg-white border-gray-200 hover:bg-gray-50'} rounded-xl p-6 border transition-all cursor-pointer hover:shadow-lg`}
            onClick={() => openProject(project)}
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'} mb-2`}>
                  {project.name}
                </h3>
                <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-3`}>
                  {project.description}
                </p>
              </div>
              <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusColor(project.status)}`}>
                {project.status}
              </span>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Images</p>
                <p className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {project.imageCount}
                </p>
              </div>
              <div>
                <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Annotations</p>
                <p className={`text-lg font-semibold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                  {project.annotationCount}
                </p>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <p className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Modified {project.lastModified.toLocaleDateString()}
              </p>
              <div className="flex gap-2">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    // Handle export
                  }}
                  className={`p-1 rounded transition-colors ${
                    darkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
                  }`}
                >
                  <Download size={16} />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    // Handle share
                  }}
                  className={`p-1 rounded transition-colors ${
                    darkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
                  }`}
                >
                  <Share2 size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAnnotationTool = () => (
    <div className="flex h-screen">
      {/* Left Sidebar */}
      <div className={`w-80 ${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-r flex flex-col transition-colors duration-200`}>
        {/* Header */}
        <div className={`p-4 border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              {selectedProject ? (
                <button
                  onClick={() => setCurrentView('projects')}
                  className={`text-sm ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'} mb-2`}
                >
                  ← Back to Projects
                </button>
              ) : (
                <button
                  onClick={() => setCurrentView('projects')}
                  className={`text-sm ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'} mb-2`}
                >
                  ← Back to Dashboard
                </button>
              )}
              <h1 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                {selectedProject?.name || 'Quick Annotation Tool'}
              </h1>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 rounded-lg transition-colors ${
                darkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
              }`}
            >
              {darkMode ? <Sun size={20} /> : <Moon size={20} />}
            </button>
          </div>
          
          <button
            onClick={() => setShowShortcuts(true)}
            className={`w-full flex items-center justify-center gap-2 px-3 py-2 rounded-lg transition-colors ${
              darkMode 
                ? 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            <Keyboard size={16} />
            <span className="text-sm">Keyboard Shortcuts (F1)</span>
          </button>
        </div>

        {/* Tools */}
        <div className={`p-4 border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
          <h3 className={`font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-800'}`}>Tools</h3>
          <div className="grid grid-cols-2 gap-2">
            <ToolButton icon={MousePointer} label="Select" isActive={tool === 'select'} onClick={() => setTool('select')} dark={darkMode} />
            <ToolButton icon={Square} label="Rectangle" isActive={tool === 'rectangle'} onClick={() => setTool('rectangle')} dark={darkMode} />
            <ToolButton icon={Circle} label="Circle" isActive={tool === 'circle'} onClick={() => setTool('circle')} dark={darkMode} />
            <ToolButton icon={Pentagon} label="Polygon" isActive={tool === 'polygon'} onClick={() => setTool('polygon')} dark={darkMode} />
            <ToolButton icon={Minus} label="Polyline" isActive={tool === 'polyline'} onClick={() => setTool('polyline')} dark={darkMode} />
            <ToolButton icon={Type} label="Text" isActive={tool === 'text'} onClick={() => setTool('text')} dark={darkMode} />
            <ToolButton icon={ZoomIn} label="Zoom" isActive={tool === 'zoom'} onClick={() => setTool('zoom')} variant="secondary" dark={darkMode} />
            <ToolButton icon={Move} label="Pan" isActive={tool === 'pan'} onClick={() => setTool('pan')} variant="secondary" dark={darkMode} />
          </div>
          
          <div className="flex gap-2 mt-3">
            <button
              onClick={() => setShowGrid(!showGrid)}
              className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                showGrid
                  ? darkMode ? 'bg-blue-600 text-white' : 'bg-blue-600 text-white'
                  : darkMode ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Grid size={16} />
              <span className="text-sm">Grid</span>
            </button>
            
            <button
              onClick={() => setShowAll(!showAll)}
              className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg transition-colors ${
                showAll
                  ? darkMode ? 'bg-green-600 text-white' : 'bg-green-600 text-white'
                  : darkMode ? 'bg-gray-700 text-gray-300 hover:bg-gray-600' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {showAll ? <Eye size={16} /> : <EyeOff size={16} />}
              <span className="text-sm">Show All</span>
            </button>
          </div>
        </div>

        {/* Class Manager */}
        <div className={`border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
          <ClassManager
            classList={classList}
            selectedClass={selectedClass}
            onClassSelect={setSelectedClass}
            onAddClass={(className) => setClassList(prev => [...prev, className])}
            onRemoveClass={(className) => {
              setClassList(prev => prev.filter(c => c !== className));
              if (selectedClass === className) {
                setSelectedClass(classList[0] || 'default');
              }
            }}
            dark={darkMode}
          />
        </div>

        {/* File Manager */}
        <div className={`border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
          <FileManager
            onImageUpload={handleImageUpload}
            onExport={handleExport}
            onImport={handleImport}
            hasImage={imageLoaded}
            annotationCount={annotations.length}
          />
        </div>

        {/* Annotation List */}
        <div className="flex-1 overflow-y-auto">
          <div className={`p-4 border-b ${darkMode ? 'border-gray-700' : 'border-gray-200'}`}>
            <h3 className={`font-semibold mb-3 ${darkMode ? 'text-white' : 'text-gray-800'}`}>
              Annotations ({annotations.length})
            </h3>
          </div>
          
          <div className="space-y-2 p-4">
            {annotations.map((annotation) => (
              <div
                key={annotation.id}
                className={`p-3 rounded-lg border transition-all cursor-pointer ${
                  selectedAnnotation === annotation.id
                    ? darkMode 
                      ? 'bg-blue-900/30 border-blue-500'
                      : 'bg-blue-50 border-blue-200'
                    : darkMode
                      ? 'bg-gray-700 border-gray-600 hover:bg-gray-600'
                      : 'bg-white border-gray-200 hover:bg-gray-50'
                }`}
                onClick={() => setSelectedAnnotation(annotation.id)}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`text-sm font-medium ${darkMode ? 'text-white' : 'text-gray-800'}`}>
                    {annotation.type} - {annotation.label}
                  </span>
                  <div className="flex gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleAnnotationVisibility(annotation.id);
                      }}
                      className={`p-1 rounded transition-colors ${
                        darkMode ? 'hover:bg-gray-600' : 'hover:bg-gray-200'
                      }`}
                    >
                      {annotation.visible ? 
                        <Eye size={14} className={darkMode ? 'text-gray-400' : 'text-gray-600'} /> : 
                        <EyeOff size={14} className={darkMode ? 'text-gray-400' : 'text-gray-600'} />
                      }
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleAnnotationLock(annotation.id);
                      }}
                      className={`p-1 rounded transition-colors ${
                        darkMode ? 'hover:bg-gray-600' : 'hover:bg-gray-200'
                      }`}
                    >
                      {annotation.locked ? 
                        <Lock size={14} className={darkMode ? 'text-gray-400' : 'text-gray-600'} /> : 
                        <Unlock size={14} className={darkMode ? 'text-gray-400' : 'text-gray-600'} />
                      }
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        duplicateAnnotation(annotation.id);
                      }}
                      className={`p-1 rounded transition-colors ${
                        darkMode ? 'hover:bg-gray-600' : 'hover:bg-gray-200'
                      }`}
                    >
                      <Copy size={14} className={darkMode ? 'text-gray-400' : 'text-gray-600'} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteAnnotation(annotation.id);
                      }}
                      className={`p-1 rounded transition-colors ${
                        darkMode ? 'hover:bg-gray-600 text-red-400' : 'hover:bg-gray-200 text-red-600'
                      }`}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
                
                {annotation.text && (
                  <div className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'} mb-1`}>
                    "{annotation.text}"
                  </div>
                )}
                
                <div className={`text-xs ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                  Points: {annotation.points.length}
                  {annotation.points.length > 0 && (
                    <span className="ml-2">
                      ({Math.round(annotation.points[0].x)}, {Math.round(annotation.points[0].y)})
                    </span>
                  )}
                </div>
              </div>
            ))}
            
            {annotations.length === 0 && (
              <div className={`text-center py-8 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                <p className="text-sm">No annotations yet</p>
                <p className="text-xs mt-1">Upload an image and start annotating</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="flex-1 flex flex-col">
        <div className="flex-1 p-4 overflow-hidden">
          <div className="h-full flex items-center justify-center">
            <Canvas
              ref={canvasRef}
              width={canvasSize.width}
              height={canvasSize.height}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onWheel={handleWheel}
              drawFunction={drawFunction}
            />
          </div>
        </div>

        {/* Status Bar */}
        <StatusBar
          tool={tool}
          scale={scale}
          mousePos={mousePos}
          polygonPoints={currentPoints.length}
          selectedAnnotation={annotations.find(ann => ann.id === selectedAnnotation)}
          annotationCount={annotations.length}
          visibleCount={annotations.filter(ann => ann.visible).length}
          lockedCount={annotations.filter(ann => ann.locked).length}
        />
      </div>
    </div>
  );

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-900' : 'bg-gray-50'} transition-colors duration-200`}>
      {/* Top Navigation */}
      <nav className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-b px-6 py-4`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                <Layers className="text-white" size={20} />
              </div>
              <span className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'}`}>
                AnnotationPro
              </span>
            </div>
            
            <div className="flex gap-1">
              <button
                onClick={() => setCurrentView('projects')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  currentView === 'projects'
                    ? darkMode ? 'bg-blue-600 text-white' : 'bg-blue-100 text-blue-800'
                    : darkMode ? 'text-gray-400 hover:text-white hover:bg-gray-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Home size={18} className="inline mr-2" />
                Projects
              </button>
              
              <button
                onClick={() => {
                  setCurrentView('annotation-tool');
                  setSelectedProject(null); // Allow quick tool without project
                }}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  currentView === 'annotation-tool' && !selectedProject
                    ? darkMode ? 'bg-green-600 text-white' : 'bg-green-100 text-green-800'
                    : darkMode ? 'text-gray-400 hover:text-white hover:bg-gray-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Square size={18} className="inline mr-2" />
                Quick Tool
              </button>
              
              {selectedProject && (
                <button
                  onClick={() => setCurrentView('annotation-tool')}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    currentView === 'annotation-tool' && selectedProject
                      ? darkMode ? 'bg-blue-600 text-white' : 'bg-blue-100 text-blue-800'
                      : darkMode ? 'text-gray-400 hover:text-white hover:bg-gray-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                >
                  <Square size={18} className="inline mr-2" />
                  Project Tool
                </button>
              )}
              
              <button
                onClick={() => setCurrentView('analytics')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  currentView === 'analytics'
                    ? darkMode ? 'bg-blue-600 text-white' : 'bg-blue-100 text-blue-800'
                    : darkMode ? 'text-gray-400 hover:text-white hover:bg-gray-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <BarChart3 size={18} className="inline mr-2" />
                Analytics
              </button>
              
              <button
                onClick={() => setCurrentView('settings')}
                className={`px-4 py-2 rounded-lg transition-colors ${
                  currentView === 'settings'
                    ? darkMode ? 'bg-blue-600 text-white' : 'bg-blue-100 text-blue-800'
                    : darkMode ? 'text-gray-400 hover:text-white hover:bg-gray-700' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <Settings size={18} className="inline mr-2" />
                Settings
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="relative">
              <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`} size={18} />
              <input
                type="text"
                placeholder="Search projects..."
                className={`pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                  darkMode 
                    ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400'
                    : 'bg-white border-gray-300 text-gray-900'
                }`}
              />
            </div>
            
            <button className={`p-2 rounded-lg transition-colors ${
              darkMode ? 'hover:bg-gray-700 text-gray-400' : 'hover:bg-gray-100 text-gray-600'
            }`}>
              <Bell size={20} />
            </button>
            
            <div className="w-8 h-8 bg-gradient-to-r from-green-400 to-blue-500 rounded-full"></div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      {currentView === 'projects' && renderProjectsView()}
      {currentView === 'annotation-tool' && renderAnnotationTool()}
      {currentView === 'analytics' && (
        <div className="p-6">
          <h1 className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
            Analytics Dashboard
          </h1>
          <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
            Analytics and reporting features coming soon...
          </p>
        </div>
      )}
      {currentView === 'settings' && (
        <div className="p-6">
          <h1 className={`text-3xl font-bold ${darkMode ? 'text-white' : 'text-gray-900'} mb-4`}>
            Settings
          </h1>
          <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
            Application settings and preferences coming soon...
          </p>
        </div>
      )}

      {/* Keyboard Shortcuts Modal */}
      {showShortcuts && (
        <KeyboardShortcuts onClose={() => setShowShortcuts(false)} dark={darkMode} />
      )}
    </div>
  );
}