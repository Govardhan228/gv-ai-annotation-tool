# Professional Annotation Tool

A comprehensive image annotation tool built with React, TypeScript, and Tailwind CSS.

## Features

- **Multiple Annotation Tools**: Rectangle, Circle, Polygon, Polyline, Text
- **Project Management**: Organize annotations into projects
- **Quick Tool**: Direct access to annotation tools
- **Dark/Light Mode**: Toggle between themes
- **Export/Import**: JSON format for annotations
- **Keyboard Shortcuts**: Efficient workflow
- **Responsive Design**: Works on all screen sizes

## Getting Started

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

## Usage

### Dashboard
- View all projects and statistics
- Create new projects
- Access Quick Tool for immediate annotation

### Annotation Tool
- Upload images
- Use various annotation tools
- Manage classes and labels
- Export annotations as JSON

### Keyboard Shortcuts
- Press F1 to view all shortcuts
- R: Rectangle tool
- C: Circle tool
- P: Polygon tool
- S: Select tool
- G: Toggle grid
- Ctrl + Mouse Wheel: Zoom

## Project Structure

- `src/App.tsx` - Main application component
- `src/components/` - Reusable components
- `src/index.css` - Global styles with Tailwind

## Technologies Used

- React 18
- TypeScript
- Tailwind CSS
- Vite
- Lucide React (icons)

## License

MIT License
